import pygame
import sys
import math
import os

from Simulator.WorldSim.world import World
from Simulator.TurtleBotSim.turtlebot import TurtleBotMock

# Configuraciones de renderizado
SCALE = 50.0
WIDTH, HEIGHT = 800, 600
OFFSET_X, OFFSET_Y = WIDTH // 2, HEIGHT // 2

def to_screen(x, y):
    return int(OFFSET_X + x * SCALE), int(OFFSET_Y - y * SCALE)

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("TurtleBot 4 - Navegación Autónoma Dinámica")
    clock = pygame.time.Clock()

    world = World()
    map_file = "world_map.json"

    if os.path.exists(map_file):
        world.load_from_file(map_file)
    else:
        print("No se encontró mapa. Usa 'test_manual_simulation.py --new' para crear uno.")
        sys.exit()

    robot = TurtleBotMock(
        world, 
        initial_x=world.robot_start['x'], 
        initial_y=world.robot_start['y'], 
        initial_theta=world.robot_start['theta']
    )

    dt = 1 / 60.0
    running = True

    estado_actual = "EXPLORANDO"
    tiempo_estado = 0.0
    cooldown_senal = 0.0

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        lidar_scan = robot.get_lidar_scan()
        vision_dets = robot.get_vision_detections()

        if cooldown_senal > 0:
            cooldown_senal -= dt

        v_target = 0.0
        w_target = 0.0

        # ========================================================
        # 1. LÓGICA DINÁMICA DE ESTADOS
        # ========================================================
        if estado_actual == "EXPLORANDO":
            dist_frente = min(lidar_scan[0:20] + lidar_scan[340:360])
            
            # Acelerar hasta 0.8 m/s si hay suficiente espacio libre
            v_target = max(0.1, min(0.8, (dist_frente - 0.4) * 0.8))
            w_target = 0.0

            if len(vision_dets) > 0 and cooldown_senal <= 0:
                senal = sorted(vision_dets, key=lambda d: d['distance'])[0]
                dist = senal['distance']
                
                # Centrar la señal en la vista (Persecución)
                w_target = senal['relative_angle'] * 2.5 
                
                # REGLA ACTUALIZADA: Iniciar maniobra a los 1.6 metros (antes 1.0)
                if dist <= 1.6:
                    if senal['class'] == 'stop':
                        estado_actual = "DETENIDO"
                        tiempo_estado = 3.0
                    elif senal['class'] == 'left':
                        estado_actual = "GIRANDO_IZQ"
                        tiempo_estado = 0.6 # "Tiempo ciego" inicial
                    elif senal['class'] == 'right':
                        estado_actual = "GIRANDO_DER"
                        tiempo_estado = 0.6 

        elif estado_actual == "DETENIDO":
            v_target = 0.0
            w_target = 0.0
            tiempo_estado -= dt
            if tiempo_estado <= 0:
                estado_actual = "EXPLORANDO"
                cooldown_senal = 3.0

        elif estado_actual in ["GIRANDO_IZQ", "GIRANDO_DER"]:
            v_target = 0.2
            w_target = 1.5 if estado_actual == "GIRANDO_IZQ" else -1.5
            
            tiempo_estado -= dt
            if tiempo_estado <= 0:
                # Comprobar si el pasillo de adelante ya está despejado
                dist_frente_estricto = min(lidar_scan[0:10] + lidar_scan[350:360])
                if dist_frente_estricto > 1.5:
                    estado_actual = "EXPLORANDO"
                    cooldown_senal = 2.5

        # ========================================================
        # 2. EVASIÓN REACTIVA: SEGUIMIENTO DE PARED PARALELA
        # ========================================================
        min_dist = float('inf')
        min_angle = 0
        
        # Ampliamos un poco el rango para detectar paredes laterales mejor (-120 a 120)
        # Revisar lado derecho (240 a 360)
        for i in range(240, 360):
            if lidar_scan[i] < min_dist:
                min_dist = lidar_scan[i]
                min_angle = i - 360
        # Revisar lado izquierdo (0 a 120)
        for i in range(0, 120):
            if lidar_scan[i] < min_dist:
                min_dist = lidar_scan[i]
                min_angle = i

        # NUEVAS DISTANCIAS: Sutil a 0.7m, Brusco a 0.4m
        if min_dist < 0.7:
            factor_giro = 1.0
            if min_dist < 0.4:
                # Modo Cambio Brusco
                factor_giro = 2.5
                v_target *= (min_dist / 0.4) # Frena gradualmente si se pega demasiado
            else:
                # Modo Cambio Sutil (0.4m - 0.7m)
                factor_giro = 1.2
                
            margen_seguridad = 0.7
            # Controlador Proporcional para alinearse paralelo al muro (90 o -90 grados)
            # Si el muro está muy cerca, el objetivo de ángulo se empuja hacia atrás (ej. 120 grados)
            # obligando al robot a alejarse hasta recuperar el margen de seguridad.
            if min_angle >= 0:
                target_angle = 90 + (margen_seguridad - min_dist) * 80.0 
                error_angulo = target_angle - min_angle
                w_target -= math.radians(error_angulo) * factor_giro
            else:
                target_angle = -90 - (margen_seguridad - min_dist) * 80.0
                error_angulo = target_angle - min_angle
                w_target -= math.radians(error_angulo) * factor_giro

        # ========================================================
        # 3. ACTUACIÓN FÍSICA
        # ========================================================
        robot.move(v_target, w_target, dt)

        # ========================================================
        # 4. RENDERIZADO VISUAL
        # ========================================================
        screen.fill((30, 30, 30))

        for p1, p2 in world.obstacles:
            pygame.draw.line(screen, (200, 200, 200), to_screen(*p1), to_screen(*p2), 2)

        font = pygame.font.SysFont(None, 24)
        for sig in world.signals:
            sx, sy = to_screen(sig['x'], sig['y'])
            pygame.draw.circle(screen, (255, 255, 0), (sx, sy), 5)
            img = font.render(sig['type'], True, (255, 255, 0))
            screen.blit(img, (sx + 10, sy - 10))

        rx, ry, rtheta = robot._get_true_pose()
        rsx, rsy = to_screen(rx, ry)

        angle_increment = (2 * math.pi) / robot.lidar_resolution
        for i, dist in enumerate(lidar_scan):
            if dist < robot.lidar_max_range:
                ray_angle = rtheta + i * angle_increment
                end_x = rx + dist * math.cos(ray_angle)
                end_y = ry + dist * math.sin(ray_angle)
                esx, esy = to_screen(end_x, end_y)
                
                # Resaltar puntos que activan las físicas de evasión (<0.7m)
                if dist < 0.7 and (i < 120 or i > 240):
                    if dist < 0.4:
                        pygame.draw.circle(screen, (255, 0, 0), (esx, esy), 2) # Rojo: Brusco
                    else:
                        pygame.draw.circle(screen, (255, 165, 0), (esx, esy), 2) # Naranja: Sutil
                else:
                    pygame.draw.circle(screen, (0, 255, 0), (esx, esy), 1)

        fov_l = rtheta + robot.camera_fov / 2
        fov_r = rtheta - robot.camera_fov / 2
        fl_x, fl_y = to_screen(rx + 2 * math.cos(fov_l), ry + 2 * math.sin(fov_l))
        fr_x, fr_y = to_screen(rx + 2 * math.cos(fov_r), ry + 2 * math.sin(fov_r))
        pygame.draw.line(screen, (0, 100, 255), (rsx, rsy), (fl_x, fl_y), 1)
        pygame.draw.line(screen, (0, 100, 255), (rsx, rsy), (fr_x, fr_y), 1)

        robot_px_radius = int(robot.radius * SCALE)
        pygame.draw.circle(screen, (50, 255, 100), (rsx, rsy), robot_px_radius)
        hx, hy = to_screen(rx + robot.radius * math.cos(rtheta), ry + robot.radius * math.sin(rtheta))
        pygame.draw.line(screen, (255, 255, 255), (rsx, rsy), (hx, hy), 3)

        screen.blit(pygame.font.SysFont(None, 36).render(f"Algoritmo: {estado_actual}", True, (255, 255, 255)), (10, 10))
        screen.blit(pygame.font.SysFont(None, 28).render(f"v={v_target:.2f}, w={w_target:.2f}", True, (200, 200, 200)), (10, 45))

        y_offset = 80
        for det in vision_dets:
            text = f"YOLO Ve: '{det['class']}' a {det['distance']:.2f}m (Ang: {math.degrees(det['relative_angle']):.1f}º)"
            img = font.render(text, True, (255, 100, 100))
            screen.blit(img, (10, y_offset))
            y_offset += 25

        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
